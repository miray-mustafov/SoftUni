# Petstagram source code

Live [here](https://petstagram.tk)

1. Setup docker for development and production - [tutorial](https://testdriven.io/blog/dockerizing-django-with-postgres-gunicorn-and-nginx/)
3. Configure nginx for prod
4. Create an EC2 service
5. Attach an Elastic IP to the service
6. Configure 
7. Register a domain
8. Configure letsencrypt/certbot for SSL - [tutorial](https://testdriven.io/blog/dockerizing-django-with-postgres-gunicorn-and-nginx/)
9. Deploy the application
