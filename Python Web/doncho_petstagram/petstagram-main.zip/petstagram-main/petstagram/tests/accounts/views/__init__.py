from .sign_up_view_tests import *
from .user_details_view_tests import *