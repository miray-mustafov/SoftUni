from django.apps import AppConfig


class InquiryConfig(AppConfig):
    name = 'inquiry'
