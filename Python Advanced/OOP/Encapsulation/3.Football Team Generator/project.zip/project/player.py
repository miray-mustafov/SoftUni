class Player:
    def __init__(self, name, sprint, dribble, passing, shooting):
        self.shooting = shooting
        self.passing = passing
        self.dribble = dribble
        self.sprint = sprint
        self.__name = name

    @property
    def name(self):
        return self.__name

    def __str__(self):
        return f"Player: {self.name}\n" \
               f"Sprint: {self.sprint}\n " \
               f"Dribble: {self.dribble}\n" \
               f"Passing: {self.passing}\n" \
               f"Shooting: {self.shooting}"
